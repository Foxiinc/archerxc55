#!/bin/bash
# Start nfqws using /opt/etc/nfqws/nfqws.conf (KEY="value" lines)
set -euo pipefail
CONF=/opt/etc/nfqws/nfqws.conf
BIN=/usr/local/bin/nfqws
QNUM=200

NFQWS_ARGS=""
NFQWS_ARGS_CUSTOM=""
# shellcheck disable=SC1090
source "$CONF"

QNUM="${NFQWS_QNUM:-$QNUM}"
ARGS=()
if [[ -n "${NFQWS_ARGS_CUSTOM:-}" ]]; then
  # CUSTOM first (same order as Keenetic)
  # shellcheck disable=SC2206
  ARGS+=($NFQWS_ARGS_CUSTOM --new)
fi
# shellcheck disable=SC2206
ARGS+=($NFQWS_ARGS)

exec "$BIN" --user=nobody --qnum="$QNUM" "${ARGS[@]}"
