#!/bin/sh
# Multi-service autostrategy for nfqws-keenetic
# NFQWS_ARGS_CUSTOM = Discord / YouTube / Rockstar / Roblox profiles (Telegram via awg2) joined by --new
# Main NFQWS_ARGS never touched. Only failing services rotate.

CONF="/opt/etc/nfqws/nfqws.conf"
STATEDIR="/opt/etc/nfqws/autostrategy.d"
LOG="/opt/var/log/autostrategy.log"
LOCK="/opt/var/run/autostrategy.lock"
INIT="/opt/etc/init.d/S51nfqws"
CURL="/opt/bin/curl"
NFQWS_DIR="/opt/etc/nfqws"

# name|hostlist|strategies|tcp_ports|url1 url2 ...
SERVICES="discord|discord.list|strategies.list|443,2053,2083,2087,2096,8443|https://discord.com https://gateway.discord.gg
youtube|youtube.list|strategies-youtube.list|443|https://www.youtube.com https://i.ytimg.com
rockstar|rockstar.list|strategies-rockstar.list|443|https://signin.rockstargames.com https://socialclub.rockstargames.com
roblox|roblox.list|strategies-roblox.list|443|https://www.roblox.com"

log() {
	echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >>"$LOG"
}

ok_http() {
	case "$1" in
	200|204|301|302|303|307|308|401|403|404) return 0 ;;
	*) return 1 ;;
	esac
}

parse_row() {
	# $1 = row -> sets _name _hlist _strat _ports _urls
	_row=$1
	_name=${_row%%|*}
	_rest=${_row#*|}
	_hlist=${_rest%%|*}
	_rest=${_rest#*|}
	_strat=${_rest%%|*}
	_rest=${_rest#*|}
	_ports=${_rest%%|*}
	_urls=${_rest#*|}
}

if [ -f "$LOCK" ]; then
	oldpid=$(cat "$LOCK" 2>/dev/null)
	if [ -n "$oldpid" ] && kill -0 "$oldpid" 2>/dev/null; then
		log "already running pid=$oldpid, exit"
		exit 0
	fi
fi
echo $$ >"$LOCK"
trap 'rm -f "$LOCK"' EXIT INT TERM

mkdir -p "$STATEDIR" /opt/var/log /opt/var/run /opt/tmp 2>/dev/null

if [ -f /opt/etc/nfqws/autostrategy.state ] && [ ! -f "$STATEDIR/discord.idx" ]; then
	cp /opt/etc/nfqws/autostrategy.state "$STATEDIR/discord.idx"
fi

read_index() {
	f="$STATEDIR/$1.idx"
	if [ -f "$f" ]; then cat "$f"; else echo 1; fi
}

write_index() {
	echo "$2" >"$STATEDIR/$1.idx"
}

load_strategies() {
	name=$1
	file=$2
	n=0
	while IFS= read -r line || [ -n "$line" ]; do
		case "$line" in
		''|\#*) continue ;;
		esac
		n=$((n + 1))
		eval "${name}_S_$n=\"\$line\""
	done <"$file"
	eval "COUNT_$name=$n"
}

get_strategy() {
	eval "echo \"\$${1}_S_$2\""
}

get_count() {
	eval "echo \"\$COUNT_$1\""
}

check_urls() {
	svc=$1
	shift
	for url in "$@"; do
		code=$("$CURL" -sS -o /dev/null -w '%{http_code}' \
			--connect-timeout 8 --max-time 20 \
			-A 'Mozilla/5.0' \
			"$url" 2>/dev/null) || code="000"
		if ok_http "$code"; then
			log "check OK [$svc] $url -> $code"
		else
			log "check FAIL [$svc] $url -> $code"
			return 1
		fi
	done
	return 0
}

build_full_custom() {
	svcfile=/opt/tmp/autostrategy.svcbuild.$$
	proffile=/opt/tmp/autostrategy.profiles.$$
	echo "$SERVICES" >"$svcfile"
	: >"$proffile"
	while IFS= read -r row || [ -n "$row" ]; do
		[ -z "$row" ] && continue
		parse_row "$row"
		idx=$(read_index "$_name")
		count=$(get_count "$_name")
		case "$idx" in
		''|*[!0-9]*) idx=1 ;;
		esac
		[ "$idx" -lt 1 ] && idx=1
		if [ -n "$count" ] && [ "$count" -ge 1 ] && [ "$idx" -gt "$count" ]; then
			idx=1
		fi
		desync=$(get_strategy "$_name" "$idx")
		[ -z "$desync" ] && continue
		echo "--filter-tcp=$_ports --hostlist=$NFQWS_DIR/$_hlist $desync" >>"$proffile"
	done <"$svcfile"
	rm -f "$svcfile"

	custom=""
	sep=""
	while IFS= read -r profile || [ -n "$profile" ]; do
		[ -z "$profile" ] && continue
		custom="${custom}${sep}${profile}"
		sep=" --new "
	done <"$proffile"
	rm -f "$proffile"
	echo "$custom"
}

apply_custom() {
	custom=$1
	tmp=$(mktemp /opt/tmp/autostrategy.XXXXXX 2>/dev/null || mktemp)
	awk -v c="$custom" '
		BEGIN { done=0 }
		/^NFQWS_ARGS_CUSTOM=/ {
			print "NFQWS_ARGS_CUSTOM=\"" c "\""
			done=1
			next
		}
		{ print }
		END {
			if (!done) print "NFQWS_ARGS_CUSTOM=\"" c "\""
		}
	' "$CONF" >"$tmp" || { rm -f "$tmp"; return 1; }

	for need in discord.list youtube.list rockstar.list roblox.list; do
		if ! grep -q "$need" "$tmp"; then
			log "refuse broken conf (no $need)"
			rm -f "$tmp"
			return 1
		fi
	done
	if ! grep -q ' --new ' "$tmp"; then
		log "refuse broken conf (no --new separators)"
		rm -f "$tmp"
		return 1
	fi

	cp "$CONF" "$CONF.bak.autostrategy" 2>/dev/null
	cat "$tmp" >"$CONF"
	rm -f "$tmp"
	log "applied multi CUSTOM"
	"$INIT" restart >>"$LOG" 2>&1
	sleep 4
	"$INIT" status >>"$LOG" 2>&1
}

rotate_service() {
	name=$1
	shift
	urls="$*"
	count=$(get_count "$name")
	if [ -z "$count" ] || [ "$count" -lt 1 ]; then
		log "[$name] empty strategy pool"
		return 1
	fi
	# Cap attempts per run so one dead service (IP-block) does not thrash nfqws all night
	max_try=$count
	[ "$max_try" -gt 6 ] && max_try=6
	start=$(read_index "$name")
	case "$start" in
	''|*[!0-9]*) start=1 ;;
	esac
	[ "$start" -lt 1 ] && start=1
	[ "$start" -gt "$count" ] && start=1

	i=$start
	tried=0
	while [ "$tried" -lt "$max_try" ]; do
		i=$((i + 1))
		[ "$i" -gt "$count" ] && i=1
		desync=$(get_strategy "$name" "$i")
		log "[$name] try #$i/$count: $desync"
		write_index "$name" "$i"
		custom=$(build_full_custom)
		apply_custom "$custom" || continue
		if check_urls "$name" $urls; then
			log "[$name] SUCCESS with #$i"
			return 0
		fi
		tried=$((tried + 1))
		sleep 2
	done
	log "[$name] no success in $max_try tries (keeping #$i)"
	return 1
}

# --- main ---
if [ ! -f "$CONF" ] || [ ! -x "$CURL" ]; then
	log "missing conf or curl"
	exit 1
fi

# Load strategies + verify files in current shell
echo "$SERVICES" > /opt/tmp/autostrategy.services.$$
while IFS= read -r row || [ -n "$row" ]; do
	[ -z "$row" ] && continue
	parse_row "$row"
	hf="$NFQWS_DIR/$_hlist"
	sf="$NFQWS_DIR/$_strat"
	if [ ! -f "$hf" ] || [ ! -f "$sf" ]; then
		log "missing $hf or $sf"
		rm -f /opt/tmp/autostrategy.services.$$
		exit 1
	fi
	load_strategies "$_name" "$sf"
	log "loaded [$_name] pool=$(get_count "$_name") list=$_hlist"
done < /opt/tmp/autostrategy.services.$$

need_apply=0
if ! grep -q 'youtube.list' "$CONF" \
	|| ! grep -q 'rockstar.list' "$CONF" \
	|| ! grep -q 'roblox.list' "$CONF" \
		|| ! grep -q 'discord.list' "$CONF"; then
	need_apply=1
	log "bootstrap multi-service CUSTOM"
fi

if [ "$need_apply" -eq 1 ]; then
	custom=$(build_full_custom)
	apply_custom "$custom" || exit 1
fi

log "=== autostrategy multi start ==="
overall=0

while IFS= read -r row || [ -n "$row" ]; do
	[ -z "$row" ] && continue
	parse_row "$row"
	idx=$(read_index "$_name")
	# "-" = keep profile in CUSTOM but do not HTTP-check / rotate
	# (e.g. Telegram: ISP IP-blocks DC ranges; curl always 000)
	if [ "$_urls" = "-" ] || [ -z "$_urls" ]; then
		log "[$_name] check skipped, keep #$idx"
		continue
	fi
	if check_urls "$_name" $_urls; then
		log "[$_name] OK, keep #$idx"
	else
		log "[$_name] DOWN, rotating..."
		if ! rotate_service "$_name" $_urls; then
			overall=1
		fi
	fi
done < /opt/tmp/autostrategy.services.$$

rm -f /opt/tmp/autostrategy.services.$$
log "=== autostrategy done exit=$overall ==="
exit $overall
