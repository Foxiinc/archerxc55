#!/bin/bash
# Install club nfqws pack on Debian/Ubuntu (Hyper-V Linux VM).
# Run as root from the unpacked pack directory:
#   sudo bash scripts/install-debian.sh
set -euo pipefail

PACK_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ARCH="$(uname -m)"
case "$ARCH" in
  x86_64|amd64) ZAPRET_ARCH=linux-x86_64 ;;
  aarch64|arm64) ZAPRET_ARCH=linux-arm64 ;;
  *) echo "unsupported arch: $ARCH"; exit 1 ;;
esac

curl_get() {
  # usage: curl_get URL OUT
  curl -fL --retry 5 --retry-delay 2 --retry-all-errors \
    --connect-timeout 20 --max-time 300 \
    -A 'club-nfqws-installer' \
    -o "$2" "$1"
}

install_nfqws_from_pack() {
  local src="$PACK_ROOT/binaries/$ZAPRET_ARCH/nfqws"
  if [ -f "$src" ]; then
    install -m 755 "$src" /usr/local/bin/nfqws
    echo "nfqws from pack ($ZAPRET_ARCH, ver $(cat "$PACK_ROOT/binaries/VERSION" 2>/dev/null || echo unknown))"
    return 0
  fi
  return 1
}

install_nfqws_from_github() {
  local tmp tag url
  tmp=$(mktemp -d)
  # resolve latest tag; fall back to known good
  tag="$(curl -fsSL --connect-timeout 15 --max-time 60 \
    https://api.github.com/repos/bol-van/zapret/releases/latest \
    | sed -n 's/.*"tag_name": *"\([^"]*\)".*/\1/p' | head -1 || true)"
  [ -n "$tag" ] || tag="v72.13"
  echo "zapret tag: $tag"

  # Correct asset name is zapret-v72.13.tar.gz (keeps the 'v')
  url="https://github.com/bol-van/zapret/releases/download/${tag}/zapret-${tag}.tar.gz"
  echo "download: $url"
  if ! curl_get "$url" "$tmp/zapret.tar.gz"; then
    echo "release asset failed, trying source archive..."
    url="https://github.com/bol-van/zapret/archive/refs/tags/${tag}.tar.gz"
    curl_get "$url" "$tmp/zapret.tar.gz"
  fi

  tar -xzf "$tmp/zapret.tar.gz" -C "$tmp"
  local bin
  bin="$(find "$tmp" -path "*/binaries/${ZAPRET_ARCH}/nfqws" -type f | head -1 || true)"
  if [ -z "$bin" ]; then
    bin="$(find "$tmp" -type f -name nfqws | head -1 || true)"
  fi
  [ -n "$bin" ] || { echo "nfqws not found in archive"; find "$tmp" -name nfqws -o -type d -name binaries 2>/dev/null | head; rm -rf "$tmp"; return 1; }
  install -m 755 "$bin" /usr/local/bin/nfqws
  rm -rf "$tmp"
  echo "nfqws from github ($tag / $ZAPRET_ARCH)"
}

echo "[1/7] packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq curl ca-certificates iptables iptables-persistent ipset cron \
  || apt-get install -y -qq curl ca-certificates iptables ipset cron

echo "[2/7] install nfqws binary"
if install_nfqws_from_pack; then
  :
else
  echo "pack binary missing, fetching from GitHub..."
  install_nfqws_from_github
fi
chmod +x /usr/local/bin/nfqws
/usr/local/bin/nfqws --help >/dev/null 2>&1 || true
echo "installed: $(command -v nfqws) ($(/usr/local/bin/nfqws --version 2>/dev/null || echo ok))"

echo "[3/7] install pack to /opt/etc/nfqws"
mkdir -p /opt/etc/nfqws/fakes /opt/etc/nfqws/autostrategy.d /var/log/club-nfqws /run/club-nfqws
cp -a "$PACK_ROOT"/lists/*.list /opt/etc/nfqws/
cp -a "$PACK_ROOT"/strategies/*.list /opt/etc/nfqws/
cp -a "$PACK_ROOT"/fakes/*.bin /opt/etc/nfqws/fakes/
install -m 755 "$PACK_ROOT/scripts/autostrategy.sh" /opt/etc/nfqws/autostrategy.sh
install -m 755 "$PACK_ROOT/scripts/nfqws-start.sh" /opt/etc/nfqws/nfqws-start.sh
cat /opt/etc/nfqws/discord.list /opt/etc/nfqws/youtube.list \
    /opt/etc/nfqws/rockstar.list /opt/etc/nfqws/roblox.list \
  | sort -u > /opt/etc/nfqws/user.list
if [ ! -f /opt/etc/nfqws/nfqws.conf ]; then
  cp "$PACK_ROOT/nfqws.conf.template" /opt/etc/nfqws/nfqws.conf
fi

echo "[4/7] systemd units"
cat >/etc/systemd/system/club-nfqws.service <<'EOF'
[Unit]
Description=Club nfqws DPI desync
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/opt/etc/nfqws/nfqws-start.sh
Restart=on-failure
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF
install -m 644 "$PACK_ROOT/systemd/club-nfqws-autostrategy.service" /etc/systemd/system/
install -m 644 "$PACK_ROOT/systemd/club-nfqws-autostrategy.timer" /etc/systemd/system/
systemctl daemon-reload

echo "[5/7] sysctl forward (VM as gateway)"
cat >/etc/sysctl.d/99-club-nfqws.conf <<'EOF'
net.ipv4.ip_forward=1
net.ipv4.conf.all.forwarding=1
net.ipv4.conf.default.forwarding=1
EOF
sysctl --system >/dev/null 2>&1 || sysctl -p /etc/sysctl.d/99-club-nfqws.conf || true

echo "[6/7] iptables NFQUEUE for forwarded TCP 80/443 + discord ports"
iptables -t mangle -N CLUB_NFQWS 2>/dev/null || iptables -t mangle -F CLUB_NFQWS
iptables -t mangle -F CLUB_NFQWS
iptables -t mangle -A CLUB_NFQWS -p tcp -m multiport --dports 80,443,2053,2083,2087,2096,8443 -j NFQUEUE --queue-num 200 --queue-bypass
iptables -t mangle -C FORWARD -j CLUB_NFQWS 2>/dev/null || iptables -t mangle -I FORWARD 1 -j CLUB_NFQWS
iptables -t mangle -C OUTPUT -j CLUB_NFQWS 2>/dev/null || iptables -t mangle -I OUTPUT 1 -j CLUB_NFQWS
if command -v netfilter-persistent >/dev/null; then
  netfilter-persistent save || true
elif command -v iptables-save >/dev/null; then
  mkdir -p /etc/iptables
  iptables-save > /etc/iptables/rules.v4 || true
fi

echo "[7/7] enable services + bootstrap strategy"
systemctl enable --now club-nfqws.service
systemctl enable --now club-nfqws-autostrategy.timer
/opt/etc/nfqws/autostrategy.sh || true

echo
echo "DONE."
echo "  nfqws: systemctl status club-nfqws"
echo "  log:   tail -f /var/log/club-nfqws/autostrategy.log"
echo "  Next: set client DHCP gateway — see docs/ON_SITE.txt"
