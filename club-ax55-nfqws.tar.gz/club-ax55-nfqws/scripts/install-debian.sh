#!/bin/bash
# Install club nfqws pack on Debian/Ubuntu x86_64 (Hyper-V Linux VM).
# Run as root from the unpacked pack directory:
#   sudo bash scripts/install-debian.sh
set -euo pipefail

PACK_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ARCH="$(uname -m)"
case "$ARCH" in
  x86_64|amd64) ZAPRET_ARCH=x86_64 ;;
  aarch64|arm64) ZAPRET_ARCH=aarch64 ;;
  *) echo "unsupported arch: $ARCH"; exit 1 ;;
esac

echo "[1/7] packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq curl ca-certificates iptables iptables-persistent ipset cron || \
  apt-get install -y -qq curl ca-certificates iptables ipset cron

echo "[2/7] fetch nfqws binary from bol-van/zapret"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
# Latest release tarball pattern — fallback to git binaries path
VER=$(curl -fsSL https://api.github.com/repos/bol-van/zapret/releases/latest | sed -n 's/.*"tag_name": *"\([^"]*\)".*/\1/p' | head -1)
if [ -z "$VER" ]; then
  echo "cannot resolve zapret latest tag"; exit 1
fi
echo "zapret $VER"
curl -fsSL -o "$TMP/zapret.tar.gz" "https://github.com/bol-van/zapret/releases/download/${VER}/zapret-${VER#v}.tar.gz" \
  || curl -fsSL -o "$TMP/zapret.tar.gz" "https://github.com/bol-van/zapret/archive/refs/tags/${VER}.tar.gz"
tar -xzf "$TMP/zapret.tar.gz" -C "$TMP"
ZDIR=$(find "$TMP" -maxdepth 2 -type d -name 'zapret*' | head -1)
NFQWS_BIN=$(find "$ZDIR" -type f -name nfqws | /usr/bin/grep -E "linux-${ZAPRET_ARCH}|${ZAPRET_ARCH}" | head -1)
if [ -z "$NFQWS_BIN" ]; then
  NFQWS_BIN=$(find "$ZDIR" -type f -path "*/binaries/*" -name nfqws | head -1)
fi
if [ -z "$NFQWS_BIN" ] || [ ! -x "$NFQWS_BIN" ]; then
  # binaries may lack +x in archive
  NFQWS_BIN=$(find "$ZDIR" -type f -name nfqws | head -1)
fi
[ -n "$NFQWS_BIN" ] || { echo "nfqws binary not found in archive"; find "$ZDIR" -name nfqws; exit 1; }
install -m 755 "$NFQWS_BIN" /usr/local/bin/nfqws
/usr/local/bin/nfqws --help >/dev/null 2>&1 || true
echo "installed $(command -v nfqws)"

echo "[3/7] install pack to /opt/etc/nfqws"
mkdir -p /opt/etc/nfqws/fakes /opt/etc/nfqws/autostrategy.d /var/log/club-nfqws /run/club-nfqws
cp -a "$PACK_ROOT"/lists/*.list /opt/etc/nfqws/
cp -a "$PACK_ROOT"/strategies/*.list /opt/etc/nfqws/
# strategies files are named strategies*.list — also need bare names used by autostrategy
cp -a "$PACK_ROOT"/strategies/strategies.list /opt/etc/nfqws/
cp -a "$PACK_ROOT"/strategies/strategies-youtube.list /opt/etc/nfqws/
cp -a "$PACK_ROOT"/strategies/strategies-rockstar.list /opt/etc/nfqws/
cp -a "$PACK_ROOT"/strategies/strategies-roblox.list /opt/etc/nfqws/
cp -a "$PACK_ROOT"/fakes/*.bin /opt/etc/nfqws/fakes/
install -m 755 "$PACK_ROOT/scripts/autostrategy.sh" /opt/etc/nfqws/autostrategy.sh
install -m 755 "$PACK_ROOT/scripts/nfqws-start.sh" /opt/etc/nfqws/nfqws-start.sh
# merge service lists into optional user.list
cat /opt/etc/nfqws/discord.list /opt/etc/nfqws/youtube.list \
    /opt/etc/nfqws/rockstar.list /opt/etc/nfqws/roblox.list \
  | sort -u > /opt/etc/nfqws/user.list
if [ ! -f /opt/etc/nfqws/nfqws.conf ]; then
  cp "$PACK_ROOT/nfqws.conf.template" /opt/etc/nfqws/nfqws.conf
fi

echo "[4/7] systemd units"
install -m 644 "$PACK_ROOT/systemd/club-nfqws.service" /etc/systemd/system/club-nfqws.service
# fix ExecStart to wrapper
cat >/etc/systemd/system/club-nfqws.service <<'EOF'
[Unit]
Description=Club nfqws DPI desync
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/opt/etc/nfqws/nfqws-start.sh
Restart=on-failure
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF
install -m 644 "$PACK_ROOT/systemd/club-nfqws-autostrategy.service" /etc/systemd/system/
install -m 644 "$PACK_ROOT/systemd/club-nfqws-autostrategy.timer" /etc/systemd/system/
systemctl daemon-reload

echo "[5/7] sysctl forward (VM as gateway)"
cat >/etc/sysctl.d/99-club-nfqws.conf <<'EOF'
net.ipv4.ip_forward=1
net.ipv4.conf.all.forwarding=1
net.ipv4.conf.default.forwarding=1
EOF
sysctl --system >/dev/null 2>&1 || sysctl -p /etc/sysctl.d/99-club-nfqws.conf

echo "[6/7] iptables NFQUEUE for forwarded TCP 80/443 + discord ports"
# Idempotent-ish: flush our chain only
iptables -t mangle -N CLUB_NFQWS 2>/dev/null || iptables -t mangle -F CLUB_NFQWS
iptables -t mangle -F CLUB_NFQWS
iptables -t mangle -A CLUB_NFQWS -p tcp -m multiport --dports 80,443,2053,2083,2087,2096,8443 -j NFQUEUE --queue-num 200 --queue-bypass
iptables -t mangle -C FORWARD -j CLUB_NFQWS 2>/dev/null || iptables -t mangle -I FORWARD 1 -j CLUB_NFQWS
# also local-origin traffic from VM itself (checks)
iptables -t mangle -C OUTPUT -j CLUB_NFQWS 2>/dev/null || iptables -t mangle -I OUTPUT 1 -j CLUB_NFQWS
if command -v netfilter-persistent >/dev/null; then
  netfilter-persistent save || true
elif command -v iptables-save >/dev/null; then
  mkdir -p /etc/iptables
  iptables-save > /etc/iptables/rules.v4 || true
fi

echo "[7/7] enable services + bootstrap strategy"
systemctl enable --now club-nfqws.service
systemctl enable --now club-nfqws-autostrategy.timer
/opt/etc/nfqws/autostrategy.sh || true

echo
echo "DONE."
echo "  nfqws: systemctl status club-nfqws"
echo "  log:   tail -f /var/log/club-nfqws/autostrategy.log"
echo "  Next: set client DHCP gateway / static route — see docs/ON_SITE.txt"
