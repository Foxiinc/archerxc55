# nfqws service packs (Keenetic)

| Service | hostlist | strategy pool | check URL |
|---|---|---|---|
| Discord | discord.list | strategies.list | https://discord.com |
| YouTube | youtube.list | strategies-youtube.list | https://www.youtube.com |
| Rockstar | rockstar.list | strategies-rockstar.list | https://signin.rockstargames.com |
| Roblox | roblox.list | strategies-roblox.list | https://www.roblox.com |
| Telegram | telegram.list | strategies-telegram.list | skipped (`-`) — ISP IP-blocks DC TCP |

Sources:
- YouTube domains: Flowseal list-google.txt + common YT CDN
- YouTube strategies: Flowseal general*.bat `--filter-tcp=443 --hostlist=list-google`
- Rockstar domains: Flowseal#10342 + bol-van#230
- Rockstar/Roblox strategies: same general pool as Discord
- Telegram domains: Flowseal/zapret-style hostlist; IPs in `telegram-ipset.list` → `/opt/etc/nfqws/ipset.list`

Wiring on nfqws-keenetic:
- Discord already in NFQWS_ARGS_CUSTOM (first profile)
- Extra services go into same CUSTOM via `--new` separators OR stay in user.list under main NFQWS_ARGS
- Prefer separate CUSTOM profiles so rotation does not break other services

Telegram note (this ISP):
- ICMP to `149.154.167.*` works; TCP 80/443/5222 times out (blackhole after ISP hops)
- nfqws hostlist/ipset stays loaded; autostrategy does **not** rotate Telegram
- Desktop clients need local MTProto / SOCKS / VPN if app still fails
